//
//  ___PROJECTNAMEASIDENTIFIER___World.h
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
//


#import "CC3World.h"
#import "CC3MeshNode.h"

/** A sample application-specific CC3World subclass.*/
@interface ___PROJECTNAMEASIDENTIFIER___World : CC3World {}

@end
